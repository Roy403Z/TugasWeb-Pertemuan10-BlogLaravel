<?php $__env->startSection('title', 'Semua Catatan'); ?>

<?php $__env->startSection('content'); ?>
  <div class="mb-10 flex flex-col gap-5 border-b-2 border-ink pb-6 sm:flex-row sm:items-end sm:justify-between">
    <div>
      <p class="text-xs font-bold uppercase tracking-[0.2em] text-ember">Belajar Laravel</p>
      <h1 class="mt-1 font-serif text-4xl font-black">Semua Catatan</h1>
      <p class="mt-1 text-sm text-stone-500"><?php echo e($posts->total()); ?> catatan ditemukan</p>
    </div>

    
    <form method="GET" action="<?php echo e(route('posts.index')); ?>" class="flex">
      <input type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari judul atau isi…"
             class="w-56 border-2 border-r-0 border-ink bg-white px-3 py-2 text-sm focus:outline-none focus:ring-4 focus:ring-ember/30 sm:w-64">
      <button class="border-2 border-ink bg-ink px-4 py-2 text-sm font-bold text-white hover:bg-ember">Cari</button>
    </form>
  </div>

  <div class="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => $post->title,'href' => route('posts.show', $post),'image' => $post->image_url]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->title),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('posts.show', $post)),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->image_url)]); ?>
        <p class="mb-5 flex-1 text-sm leading-relaxed text-stone-600"><?php echo e($post->excerpt); ?></p>

        <div class="flex items-center justify-between border-t-2 border-dashed border-stone-300 pt-3 text-xs">
          <span class="font-semibold text-stone-500"><?php echo e($post->created_at->translatedFormat('d M Y')); ?></span>
          <div class="flex items-center gap-3 font-bold">
            <a href="<?php echo e(route('posts.edit', $post)); ?>" class="hover:text-ember hover:underline">Edit</a>

            
            <form method="POST" action="<?php echo e(route('posts.destroy', $post)); ?>"
                  onsubmit="return confirm('Pindahkan catatan ini ke tempat sampah?')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="text-red-600 hover:underline">Hapus</button>
            </form>
          </div>
        </div>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="col-span-full border-2 border-dashed border-ink bg-white p-10 text-center text-stone-600">
        Belum ada catatan<?php echo e(request('q') ? ' yang cocok dengan "'.e(request('q')).'"' : ''); ?>.
        <a href="<?php echo e(route('posts.create')); ?>" class="font-bold text-ember underline">Tulis catatan pertama</a>.
      </p>
    <?php endif; ?>
  </div>

  
  <div class="mt-10">
    <?php echo e($posts->links()); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\TugasWeb-P10-BlogLaravel\resources\views/posts/index.blade.php ENDPATH**/ ?>