
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'href' => null, 'image' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'href' => null, 'image' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article <?php echo e($attributes->class(['flex flex-col overflow-hidden border-2 border-ink bg-white shadow-[5px_5px_0_0_#1f1a17] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_0_#ef3b2d]'])); ?>>
  <?php if($image): ?>
    <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="h-40 w-full border-b-2 border-ink object-cover">
  <?php else: ?>
    <div class="h-2 bg-ember"></div>
  <?php endif; ?>

  <div class="flex flex-1 flex-col p-5">
    <h2 class="mb-3 font-serif text-xl font-extrabold leading-snug">
      <?php if($href): ?>
        <a href="<?php echo e($href); ?>" class="hover:text-ember"><?php echo e($title); ?></a>
      <?php else: ?>
        <?php echo e($title); ?>

      <?php endif; ?>
    </h2>

    <?php echo e($slot); ?>

  </div>
</article>
<?php /**PATH C:\laragon\www\TugasWeb-P10-BlogLaravel\resources\views/components/card.blade.php ENDPATH**/ ?>