<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->string('title', 150);
            $table->text('content');
            $table->string('image')->nullable(); // BONUS: upload gambar
            $table->timestamps();
            $table->softDeletes();               // BONUS: soft delete
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('posts');
    }
};
